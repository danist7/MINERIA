La única libreria que hemos usado (pero que creemos que está por defecto en python)
es heapq.
