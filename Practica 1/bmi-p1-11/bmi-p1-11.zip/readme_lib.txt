La única libreria que se ha utilizado para las gráficas ha sido "matplotlib".
Solo se usa en el fichero statistics.py y se instala de la siguiente manera:
pip3 install matplotlib

Es importante que se ejecute el main.py desde la carpeta que contiene las colecciones
ya que si no es posible que el builder no funcione bien. Si hubiese algún problema no dude
en contactar a los siguientes correos:
juan.velascoi@estudiante.uam.es
daniel.santo-tomas@estudiante.uam.es
